const express = require("express");
const path = require("path");
const crypto = require("crypto");
const multer = require("multer");
const gridFsStorage = require("multer-gridfs-storage");
const grid = require("gridfs-stream");
const methodOverride = require("method-override");
const bodyParser = require("body-parser");
const ejs = require("ejs");
const mongoose = require('mongoose');

//adding parentheses on date() so that the function of getDate is logged into the console.log
// console.log(date());

const app = express();
// Middleware//
app.use(methodOverride('_method'));
app.use(express.static(__dirname + "/public"));
app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({
  extended: true
}));




const DB_URI = "mongodb+srv://Valencify:V@lencify@123@cluster0-lam39.mongodb.net/test?retryWrites=true&w=majority";
const mongoDB = mongoose.connect(DB_URI, { useNewUrlParser: true, useUnifiedTopology: true });
const conn = mongoose.createConnection(DB_URI,{useNewUrlParser: true, useUnifiedTopology: true });

// const mongoDB = mongoose.connection;
// database createConnection
// function connectToMongoDB(cb) {
//  var mongoDB = mongoose.connection;
//  mongoose.connect(DB_URI, { useNewUrlParser: true, useUnifiedTopology: true });
//
//  mongoDB.on('error', function cb() {
//   console.log('Error when connecting to db ');
//  });
//
//  mongoDB.once('open', function cb() {
//   console.log('Successfully connected to database ');
//  });
//
//  return cb(null, mongoDB);
// }


//Init gfs

let gfs;
conn.once('open', function () {
  gfs = grid(conn.db,mongoose.mongo);
  gfs.collection('merch_forms');
})

//Create Storage engine

const storage = new gridFsStorage({
  url: DB_URI,
  file: (req, file) => {
    return new Promise((resolve, reject) => {
      crypto.randomBytes(16, (err, buf) => {
        if (err) {
          return reject(err);
        }
        const filename = buf.toString('hex') + path.extname(file.originalname);
        const fileInfo = {
          filename: filename,
          bucketName: 'merch_forms'
        };
        resolve(fileInfo);
      });
    });
  }
});
const upload = multer({ storage });

const userSchema ={
  email:String,
  password:String,

};



const schema = {
  title: String,
  body: String,
  link: String,
  contact: Number,
  category: [String],
  year: String,
  branch: String,
  gender: String,
  date: Date,
  duration: String,
  file: String

};





const Valencify_user_merchant = mongoose.model("Valencify_user_merchant",userSchema);

const merch_form = mongoose.model("merch_form", schema);

// .....................create a sample user.......................//

// const valencifyuser = new Valencify_merchant({
//   email:"Hello",
//   password:"qwerty"
// });
//
// valencifyuser.save();
// .....................create a sample user.......................//

// const storage = multer.diskStorage({
//   destination: function(req,file,cb){
//     cb(null,'./public/uploads/')
//   },
//   filename: (req,file,cb) =>{
//     cb(null,file.fieldname+"_"+Date.now()+path.extname(file.originalname));
//   }
// });
//
// var upload = multer({
//   storage: storage
// }).single('file');


app.get("/", function(req, res) {


  res.render("index");

});

app.get("/index", function(req, res) {


  res.render("index");

});

app.get("/contact", function(req, res) {


  res.render("contact");

});

app.get("/business", function(req, res) {


  res.render("business");

});
app.get("/Register", function(req, res) {


  res.render("Register");

});
app.get("/Marketing", function(req, res) {


  res.render("Marketing");

});

app.get("/marketing_next", function(req, res) {


  res.render("marketing_next");

});

app.get("/bmf",function(req,res){
  res.render("bmf");
});

app.get("/sucess_bmf",function(req,res){
  res.render("sucess_bmf");
});

app.get("/marketing_form", function(req, res) {


  res.render("marketing_form");

});

app.get("/sucess", function(req, res) {


  res.render("sucess");

});

app.get("/post", function(req, res) {


  res.render("post");

});


app.post("/business",function(req,res){
  const username = req.body.username;
  const password = req.body.password;

  Valencify_user_merchant.findOne({email: username},function(err,foundUser){
    if(err){
      console.log(err);
    }else{
      if(foundUser){
        if(foundUser.password === password){
          res.render("secret");
        }
      }
    }
  });
});


app.post("/post",upload.single('file'),function(req,res){
  const merchant = new merch_form({
    title: req.body.title,
    body: req.body.body,
    link: req.body.link,
    contact: req.body.contact,
    category: req.body.category,
    year: req.body.year,
    branch: req.body.branch,
    gender: req.body.gender,
    date: req.body.date,
    duration: req.body.duration,
    file: req.file.file,
  });
  merchant.save(function(err){
    if(err){
      console.log(err);
    }else{
      res.render("sucess");
    }
  });
});


app.listen(process.env.PORT||3000, function() {

  console.log("Server is running on 3000");
});
