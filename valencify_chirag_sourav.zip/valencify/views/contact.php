<?php

if(isset($_POST['submit'])){

  $Fname = $_POST['fname'] ;
  $Lname =  $_POST['lname'];
  $mailFrom = $_POST['email'];
  $messgae =  $_POST['message'];


  $mailTo = "tripathi.shivanshi13@gmail.com";
  $header = "From:".$mailFrom;
  $txt = "You have received a mail from".$Fname".\n\n".$messgae;


  mail($mailTo,$subject,$txt,$header);
  header("Location:contact.ejs?mailsend");
}

?>
